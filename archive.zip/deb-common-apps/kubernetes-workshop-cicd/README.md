# k8s-cicd

### Created this for implementing CI/CD for Kubernetes