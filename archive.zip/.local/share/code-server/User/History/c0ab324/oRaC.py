import time

while True:
    print("Hello all , welcome to python..!!")
    time.sleep(3)
    print("Welcome to Roche..")
    time.sleep(2)
    print("Welcome to Containers ..!!")
    print("______________________")
    time.sleep(3)